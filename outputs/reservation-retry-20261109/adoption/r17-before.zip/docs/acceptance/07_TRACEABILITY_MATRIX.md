# トレーサビリティーマトリックス

現行正本版：2026-11-07-r17。生成元 [registry.json](../traceability/registry.json)。過去の合格記録とは別。

<!-- fact:authentication="google" -->
<!-- fact:setupOwner="developer" -->
<!-- fact:dailyAccountOwner="admin" -->
<!-- fact:consumeAt="completion" -->
<!-- fact:oneWay=1 -->
<!-- fact:roundTrip=2 -->
<!-- fact:calendarPermissionAdded=true -->
<!-- fact:productionStarted=false -->
<!-- fact:originalLedgerAutoSync=false -->
<!-- fact:thirdPartyPassed=0 -->
<!-- fact:thirdPartyTotal=30 -->
<!-- fact:thirdPartyRequiredForRelease=false -->
<!-- fact:customerAcceptancePassed=0 -->
<!-- fact:customerAcceptanceTotal=6 -->
<!-- fact:calendarPermissionApprovedForTest=true -->
<!-- fact:remainingRealAcceptance=["AT-24","AT-25","AT-26","AT-27","AT-28","AT-29","AT-30"] -->
<!-- fact:release="HOLD" -->
<!-- fact:restoredAdminRelogin="BOTH_ADMINS_CONFIRMED" -->
<!-- fact:publicFrontendFilesMatched=7 -->
<!-- fact:restoredActiveAdmins=2 -->
<!-- fact:verificationGasVersion=6 -->
<!-- fact:verificationCalendarReadConfirmed=true -->
<!-- fact:customerPreparationStatus="SELF_PACED_PREPARED_CUSTOMER_FIRST_LOGIN_PENDING" -->
<!-- fact:customerExecutionMode="self-paced-test-reviewer" -->

初期設定は開発担当、日常の利用登録は管理者が行う。片道1枚・往復2枚を完了時に消費する。小林さんの顧客確認は0/6件合格。原AT-01〜30は開発担当が技術検証する。旧第三者受入0/30件は履歴。検証専用Calendarの権限追加は許可済み、Googleの実同意済み。本番開始は保留中。 [顧客確認の6手順](CUSTOMER_ACCEPTANCE_MINIMUM_20261107.md)

ユーザー指定の10工程を左から右に対応。N/A・未実装・テスト不足は隠さない。

| 業務フロー | 要件 | 設計 | 試験仕様 | タスク | 実装項目 | テストコード | 受入仕様 | 運用 | 利用者手順 | 自動テスト対応漏れ | 旧第三者実施欄／補足試験状態 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| BF-01 | REQ-01 | FS-01 | TS-01 | TASK-01 | CODE-01 | TEST-01 | AT-01 | OPS-01 | USR-01 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-02 | REQ-02 | FS-02 | TS-02 | TASK-02 | CODE-02 | TEST-02 | AT-02 | OPS-02 | USR-02 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-03 | REQ-03 | FS-03 | TS-03 | TASK-03 | CODE-03 | TEST-03 | AT-03 | OPS-03 | USR-03 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-03 | REQ-04 | FS-04 | TS-04 | TASK-04 | CODE-04 | TEST-04 | AT-04 | OPS-04 | USR-04 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-03 | REQ-05 | FS-05 | TS-05 | TASK-05 | CODE-05 | TEST-05 | AT-05 | OPS-05 | USR-05 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-04 | REQ-06 | FS-06 | TS-06 | TASK-06 | CODE-06 | TEST-06 | AT-06 | OPS-06 | USR-06 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-04 | REQ-07 | FS-07 | TS-07 | TASK-07 | CODE-07 | TEST-07 | AT-07 | OPS-07 | USR-07 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-04 | REQ-08 | FS-08 | TS-08 | TASK-08 | CODE-08 | TEST-08 | AT-08 | OPS-08 | USR-08 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-04 | REQ-09 | FS-09 | TS-09 | TASK-09 | CODE-09 | TEST-09 | AT-09 | OPS-09 | USR-09 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-05 | REQ-10 | FS-10 | TS-10 | TASK-10 | CODE-10 | TEST-10 | AT-10 | OPS-10 | USR-10 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-05 | REQ-11 | FS-11 | TS-11 | TASK-11 | CODE-11 | TEST-11 | AT-11 | OPS-11 | USR-11 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-06 | REQ-12 | FS-12 | TS-12 | TASK-12 | CODE-12 | TEST-12 | AT-12 | OPS-12 | USR-12 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-06 | REQ-13 | FS-13 | TS-13 | TASK-13 | CODE-13 | TEST-13 | AT-13 | OPS-13 | USR-13 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-06 | REQ-14 | FS-14 | TS-14 | TASK-14 | CODE-14 | TEST-14 | AT-14 | OPS-14 | USR-14 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-06 | REQ-15 | FS-15 | TS-15 | TASK-15 | CODE-15 | TEST-15 | AT-15 | OPS-15 | USR-15 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-06 | REQ-16 | FS-16 | TS-16 | TASK-16 | CODE-16 | TEST-16 | AT-16 | OPS-16 | USR-16 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-03 | REQ-17 | FS-17 | TS-17 | TASK-17 | CODE-17 | TEST-17 | AT-17 | OPS-17 | USR-17 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-07 | REQ-18 | FS-18 | TS-18 | TASK-18 | CODE-18 | TEST-18 | AT-18 | OPS-18 | USR-18 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-07 | REQ-19 | FS-19 | TS-19 | TASK-19 | CODE-19 | TEST-19 | AT-19 | OPS-19 | USR-19 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-07 | REQ-20 | FS-20 | TS-20 | TASK-20 | CODE-20 | TEST-20 | AT-20 | OPS-20 | USR-20 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-08 | REQ-21 | FS-21 | TS-21 | TASK-21 | CODE-21 | TEST-21 | AT-21 | OPS-21 | USR-21 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-07 | REQ-22 | FS-22 | TS-22 | TASK-22 | CODE-22 | TEST-22 | AT-22 | OPS-22 | USR-22 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-01 | REQ-23 | FS-23 | TS-23 | TASK-23 | CODE-23 | TEST-23 | AT-23 | OPS-23 | USR-23 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-04 | REQ-24 | FS-24 | TS-24 | TASK-24 | CODE-24 | TEST-24 | AT-24 | OPS-24 | USR-24 | 関連テストあり（適合範囲は要レビュー） | BLOCKED |
| BF-05 | REQ-25 | FS-25 | TS-25 | TASK-25 | CODE-25 | TEST-25 | AT-25 | OPS-25 | USR-25 | 関連テストあり（適合範囲は要レビュー） | BLOCKED |
| BF-07 | REQ-26 | FS-26 | TS-26 | TASK-26 | CODE-26 | TEST-26 | AT-26 | OPS-26 | USR-26 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-06 | REQ-27 | FS-27 | TS-27 | TASK-27 | CODE-27 | TEST-27 | AT-27 | OPS-27 | USR-27 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-08 | REQ-28 | FS-28 | TS-28 | TASK-28 | CODE-28 | TEST-28 | AT-28 | OPS-28 | USR-28 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-08 | REQ-29 | FS-29 | TS-29 | TASK-29 | CODE-29 | TEST-29 | AT-29 | OPS-29 | USR-29 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-08 | REQ-30 | FS-30 | TS-30 | TASK-30 | CODE-30 | TEST-30 | AT-30 | OPS-30 | USR-30 | 関連テストあり（適合範囲は要レビュー） | BLOCKED |
| BF-09 | REQ-31 | FS-31 | TS-31 | TASK-31 | CODE-31 | TEST-31 | SAT-31 | OPS-31 | USR-31 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-09 | REQ-32 | FS-32 | TS-32 | TASK-32 | CODE-32 | TEST-32 | SAT-32 | OPS-32 | USR-32 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-09 | REQ-33 | FS-33 | TS-33 | TASK-33 | CODE-33 | TEST-33 | SAT-33 | OPS-33 | USR-33 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-07 | REQ-34 | FS-34 | TS-34 | TASK-34 | CODE-34 | TEST-34 | SAT-34 | OPS-34 | USR-34 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-10 | REQ-35 | FS-35 | TS-35 | TASK-35 | CODE-35 | TEST-35 | SAT-35 | OPS-35 | USR-35 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-06 | REQ-36 | FS-36 | TS-36 | TASK-36 | CODE-36 | TEST-36 | SAT-36 | OPS-36 | USR-36 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-05 | REQ-37 | FS-37 | TS-37 | TASK-37 | CODE-37 | TEST-37 | SAT-37 | OPS-37 | USR-37 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-11 | REQ-38 | FS-38 | TS-38 | TASK-38 | CODE-38 | TEST-38 | SAT-38 | OPS-38 | USR-38 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |
| BF-08 | REQ-39 | FS-39 | TS-39 | TASK-39 | CODE-39 | TEST-39 | SAT-39 | OPS-39 | USR-39 | 関連テストあり（適合範囲は要レビュー） | NOT_RUN |

## 対応漏れ・未確定・解消記録

- OPEN-01：取消期限・当日変更・返金・片道だけ実施の精算（CUSTOMER_CONFIRMATION）
- OPEN-02：バックアップ担当・頻度・保管先（CUSTOMER_CONFIRMATION）
- OPEN-03：旧方針の本番前第三者30件は廃止。AT-30は本番配備後の開発側確認（RESOLVED）
- OPEN-04：復元後の管理者2名の再ログイン確認（RESOLVED）
