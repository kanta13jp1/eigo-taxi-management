# タスクリスト

現行正本版：2026-11-07-r17。生成元 [registry.json](../traceability/registry.json)。過去の合格記録とは別。

<!-- fact:authentication="google" -->
<!-- fact:setupOwner="developer" -->
<!-- fact:dailyAccountOwner="admin" -->
<!-- fact:consumeAt="completion" -->
<!-- fact:oneWay=1 -->
<!-- fact:roundTrip=2 -->
<!-- fact:calendarPermissionAdded=true -->
<!-- fact:productionStarted=false -->
<!-- fact:originalLedgerAutoSync=false -->
<!-- fact:thirdPartyPassed=0 -->
<!-- fact:thirdPartyTotal=30 -->
<!-- fact:thirdPartyRequiredForRelease=false -->
<!-- fact:customerAcceptancePassed=0 -->
<!-- fact:customerAcceptanceTotal=6 -->
<!-- fact:calendarPermissionApprovedForTest=true -->
<!-- fact:remainingRealAcceptance=["AT-24","AT-25","AT-26","AT-27","AT-28","AT-29","AT-30"] -->
<!-- fact:release="HOLD" -->
<!-- fact:restoredAdminRelogin="BOTH_ADMINS_CONFIRMED" -->
<!-- fact:publicFrontendFilesMatched=7 -->
<!-- fact:restoredActiveAdmins=2 -->
<!-- fact:verificationGasVersion=6 -->
<!-- fact:verificationCalendarReadConfirmed=true -->
<!-- fact:customerPreparationStatus="SELF_PACED_PREPARED_CUSTOMER_FIRST_LOGIN_PENDING" -->
<!-- fact:customerExecutionMode="self-paced-test-reviewer" -->

初期設定は開発担当、日常の利用登録は管理者が行う。片道1枚・往復2枚を完了時に消費する。小林さんの顧客確認は0/6件合格。原AT-01〜30は開発担当が技術検証する。旧第三者受入0/30件は履歴。検証専用Calendarの権限追加は許可済み、Googleの実同意済み。本番開始は保留中。 [顧客確認の6手順](CUSTOMER_ACCEPTANCE_MINIMUM_20261107.md)

<a id="TASK-01"></a>
## TASK-01 開発者設定とGoogleログイン

参照：BF-01 / REQ-01 / FS-01 / TS-01 / TASK-01 / CODE-01 / TEST-01 / AT-01 / OPS-01 / USR-01

受入確認タスク：管理者URLを開く。接続先URL・キー入力欄がないことを確認しGoogleで本人を選択。台帳取得後に再読込し、ログアウトする。

完了条件：許可された管理者だけが管理画面・検証台帳へ接続。再読込で本人を再確認し、ログアウト後は台帳を表示しない。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

今回の実環境観測：RA-01/02：復元後の管理者2名それぞれの新規Googleログイン、本人名義・生徒3名・送迎履歴3件、再読込保持、ログアウト後の再読込で台帳非表示を確認。 [確認記録](restored-admins-2026-10-23/README.md)

<a id="TASK-02"></a>
## TASK-02 生徒登録

参照：BF-02 / REQ-02 / FS-02 / TS-02 / TASK-02 / CODE-02 / TEST-02 / AT-02 / OPS-02 / USR-02

受入確認タスク：生徒登録画面で氏名・保護者・住所・連絡先・初期10回を登録。

完了条件：生徒が1件増え全入力値と初期残高10が保存される。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-03"></a>
## TASK-03 保護者の残数確認

参照：BF-03 / REQ-03 / FS-03 / TS-03 / TASK-03 / CODE-03 / TEST-03 / AT-03 / OPS-03 / USR-03

受入確認タスク：登録済み保護者が家庭専用URLからGoogleで入り、自家庭のお子様の氏名・残高・説明を確認。他家庭が選べないことを確認。

完了条件：氏名と7回分・片道1枚の説明が表示される。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-04"></a>
## TASK-04 残少・ゼロ案内

参照：BF-03 / REQ-04 / FS-04 / TS-04 / TASK-04 / CODE-04 / TEST-04 / AT-04 / OPS-04 / USR-04

受入確認タスク：各残高で利用者画面を開く。

完了条件：各値でMauro・Brendaへの連絡案内が表示される。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-05"></a>
## TASK-05 チケット追加

参照：BF-03 / REQ-05 / FS-05 / TS-05 / TASK-05 / CODE-05 / TEST-05 / AT-05 / OPS-05 / USR-05

受入確認タスク：10回を追加し台帳・購入履歴を確認。

完了条件：残高17、履歴1件増、枚数10・金額・備考一致。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-06"></a>
## TASK-06 保護者のお迎え予約

参照：BF-04 / REQ-06 / FS-06 / TS-06 / TASK-06 / CODE-06 / TEST-06 / AT-06 / OPS-06 / USR-06

受入確認タスク：利用者画面から2026-10-20 16:30・お迎え・登録済み住所を使って予約。

完了条件：新規予約1件、scheduled、parent、残高7のまま。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-07"></a>
## TASK-07 送り予約

参照：BF-04 / REQ-07 / FS-07 / TS-07 / TASK-07 / CODE-07 / TEST-07 / AT-07 / OPS-07 / USR-07

受入確認タスク：サービス経由で送り17:30を登録し画面を再表示。

完了条件：dropoffの予約が1件増え、残高7のまま。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-08"></a>
## TASK-08 往復予約

参照：BF-04 / REQ-08 / FS-08 / TS-08 / TASK-08 / CODE-08 / TEST-08 / AT-08 / OPS-08 / USR-08

受入確認タスク：サービス経由で往復を登録し画面を再表示。

完了条件：roundtripの予約が1件増え、予約時残高7のまま。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-09"></a>
## TASK-09 管理者の代理予約

参照：BF-04 / REQ-09 / FS-09 / TS-09 / TASK-09 / CODE-09 / TEST-09 / AT-09 / OPS-09 / USR-09

受入確認タスク：管理者画面から日時・生徒・場所を指定して予約。

完了条件：新規予約1件、reservedBy=teacher。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-10"></a>
## TASK-10 保護者の予約取消

参照：BF-05 / REQ-10 / FS-10 / TS-10 / TASK-10 / CODE-10 / TEST-10 / AT-10 / OPS-10 / USR-10

受入確認タスク：利用者画面で対象予約をキャンセルし確認を承諾。

完了条件：対象IDがcancelled、残高7のまま。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-11"></a>
## TASK-11 管理者の予約取消

参照：BF-05 / REQ-11 / FS-11 / TS-11 / TASK-11 / CODE-11 / TEST-11 / AT-11 / OPS-11 / USR-11

受入確認タスク：サービス経由で取消後に管理画面を再表示。

完了条件：対象IDがcancelled、残数不変。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-12"></a>
## TASK-12 当日一覧・地図リンク

参照：BF-06 / REQ-12 / FS-12 / TS-12 / TASK-12 / CODE-12 / TEST-12 / AT-12 / OPS-12 / USR-12

受入確認タスク：管理者画面を開き地図リンクを調べる。

完了条件：当日予約とGoogle Maps検索URLが表示される（地図先の動作は対象外）。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-13"></a>
## TASK-13 片道完了

参照：BF-06 / REQ-13 / FS-13 / TS-13 / TASK-13 / CODE-13 / TEST-13 / AT-13 / OPS-13 / USR-13

受入確認タスク：サービス経由で完了後に画面を再表示。

完了条件：completed・完了日時あり・残高6。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-14"></a>
## TASK-14 往復完了

参照：BF-06 / REQ-14 / FS-14 / TS-14 / TASK-14 / CODE-14 / TEST-14 / AT-14 / OPS-14 / USR-14

受入確認タスク：サービス経由で往復完了後に画面を再表示。

完了条件：completed・残高5・消費2。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-15"></a>
## TASK-15 完了の二重処理防止

参照：BF-06 / REQ-15 / FS-15 / TS-15 / TASK-15 / CODE-15 / TEST-15 / AT-15 / OPS-15 / USR-15

受入確認タスク：同じ予約IDに完了を2回要求。

完了条件：最終残高6、completedを保持、再処理の消費枚数0。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-16"></a>
## TASK-16 取消済みの完了拒否

参照：BF-06 / REQ-16 / FS-16 / TS-16 / TASK-16 / CODE-16 / TEST-16 / AT-16 / OPS-16 / USR-16

受入確認タスク：取消済みIDを完了要求。

完了条件：cancelledを保持し残高7のまま。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-17"></a>
## TASK-17 不正なチケット追加拒否

参照：BF-03 / REQ-17 / FS-17 / TS-17 / TASK-17 / CODE-17 / TEST-17 / AT-17 / OPS-17 / USR-17

受入確認タスク：枚数に-1/0/小数/NaN/Infinity/101、金額に負数/小数/NaN/Infinityを渡す。

完了条件：全要求が拒否され残高7・購入履歴が不変。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-18"></a>
## TASK-18 通信障害時に成功扱いしない

参照：BF-07 / REQ-18 / FS-18 / TS-18 / TASK-18 / CODE-18 / TEST-18 / AT-18 / OPS-18 / USR-18

受入確認タスク：全5更新POSTを通信失敗させる。業務エラー/HTTP503/不正JSONも拒否確認。同一予約を再試行しUIでも予約する。

完了条件：すべて拒否、ローカル台帳不変、同一内容再試行の予約ID不変、UIにエラー表示してフォーム維持。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-19"></a>
## TASK-19 未認証の管理操作を拒否

参照：BF-07 / REQ-19 / FS-19 / TS-19 / TASK-19 / CODE-19 / TEST-19 / AT-19 / OPS-19 / USR-19

受入確認タスク：未認証の画面とAPI拒否を確認。その後ローカル模擬APIでログインし、キー失効応答を注入する。

完了条件：認証前はログイン画面のみ・台帳未生成。キー失効応答後はセッションと画面の個人情報を消しログイン画面に戻る。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

今回の実環境観測：RA-03：公開管理者入口で未認証時に台帳非表示を確認。未認証API拒否を含むAT-19全体の再合格ではない。 [確認記録](restored-admins-2026-10-23/README.md)

<a id="TASK-20"></a>
## TASK-20 保護者の家庭別アクセス制限

参照：BF-07 / REQ-20 / FS-20 / TS-20 / TASK-20 / CODE-20 / TEST-20 / AT-20 / OPS-20 / USR-20

受入確認タスク：生徒一覧・予約一覧・STU-002への参照/予約/取消・管理者操作の直接呼出を確認。

完了条件：STU-001だけを表示。別家庭の参照/予約/取消と完了/チケット追加を拒否。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-21"></a>
## TASK-21 モバイル表示

参照：BF-08 / REQ-21 / FS-21 / TS-21 / TASK-21 / CODE-21 / TEST-21 / AT-21 / OPS-21 / USR-21

受入確認タスク：管理・利用者・予約フォームを順に表示し、指定幅375pxと実際の描画幅を照合。

完了条件：各画面でscrollWidthとinnerWidthが375px以下。保護者の予約・取消行も画面内に収まる。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-22"></a>
## TASK-22 再読込後の永続化

参照：BF-07 / REQ-22 / FS-22 / TS-22 / TASK-22 / CODE-22 / TEST-22 / AT-22 / OPS-22 / USR-22

受入確認タスク：生徒追加と予約登録後に再読込。

完了条件：追加した生徒・予約のIDと値が維持される。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-23"></a>
## TASK-23 Google初期化・永続化

参照：BF-01 / REQ-23 / FS-23 / TS-23 / TASK-23 / CODE-23 / TEST-23 / AT-23 / OPS-23 / USR-23

受入確認タスク：initSpreadsheetを2回実行し生徒をWeb登録、シートを開く。

完了条件：3シート生成・再実行で既存値不変・新規生徒1行。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-24"></a>
## TASK-24 実カレンダー予約同期

参照：BF-04 / REQ-24 / FS-24 / TS-24 / TASK-24 / CODE-24 / TEST-24 / AT-24 / OPS-24 / USR-24

受入確認タスク：Webから予約し、シート行のイベントIDで実カレンダー予定を特定して説明欄・日時・場所を照合する。

完了条件：予定説明欄の予約IDが台帳の予約IDと一致し、台帳イベントIDで特定した予定の日時・場所も一致。

状態：HOLD。実装参照が存在することと受入合格は別。

<a id="TASK-25"></a>
## TASK-25 実カレンダー取消同期

参照：BF-05 / REQ-25 / FS-25 / TS-25 / TASK-25 / CODE-25 / TEST-25 / AT-25 / OPS-25 / USR-25

受入確認タスク：予約取消後にシートとカレンダーを開く。

完了条件：cancelled・対象イベント削除・残高不変。

状態：HOLD。実装参照が存在することと受入合格は別。

<a id="TASK-26"></a>
## TASK-26 管理者2名・保護者の端末共有

参照：BF-07 / REQ-26 / FS-26 / TS-26 / TASK-26 / CODE-26 / TEST-26 / AT-26 / OPS-26 / USR-26

受入確認タスク：保護者予約 → 管理者A確認・完了 → 管理者Bと保護者が再取得。

完了条件：同一予約・残高を確認し家庭の範囲を維持。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

今回の実環境観測：RA-01/02/07/08：復元後の管理者2名の本人ログイン・再読込・ログアウトを確認。両管理者から有効・本人確認済み2名と一時家庭なしを読取り照合。予約・完了・他端末の更新共有を含むAT-26全体は未完。 [確認記録](restored-admins-2026-10-23/README.md)

<a id="TASK-27"></a>
## TASK-27 同時完了の排他制御

参照：BF-06 / REQ-27 / FS-27 / TS-27 / TASK-27 / CODE-27 / TEST-27 / AT-27 / OPS-27 / USR-27

受入確認タスク：同じ予約を両管理者から同時に完了。

完了条件：完了1件・片道1枚だけ消費、再試行でも不変。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

今回の実環境観測：AT27-LIVE-01/02：2管理者の同時完了で3枚→2枚。別の専用送迎を管理者1で完了確定後、完了前の管理者2画面から明示再試行して追加0枚・残数2枚・送迎行と完了日時不変を確認。試験行除去後に主要3シートの実行前範囲一致。開発側の期待値確認は完了、独立した第三者受入は未実施。 [確認記録](concurrent-completion-plan-2026-10-23/README.md)

<a id="TASK-28"></a>
## TASK-28 バックアップから復旧

参照：BF-08 / REQ-28 / FS-28 / TS-28 / TASK-28 / CODE-28 / TEST-28 / AT-28 / OPS-28 / USR-28

受入確認タスク：バックアップ → テスト行変更 → 復元 → Web再取得。

完了条件：生徒・予約・購入履歴・カレンダーの整合を回復。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

今回の実環境観測：AT28-LIVE-01〜08：専用生徒・送迎・購入の3行をコピーから値復元して一致。会社Googleログイン後にWeb再取得で残数3・時刻16:30を確認。購入3枚は台帳で照合。IDガードした3行を除去し主要3シート先頭8行のSHA-256が実行前と一致、Webも元の生徒3名・履歴3件。台帳部分確認完了、Calendar整合・全体合格は未確認。 [確認記録](backup-restore-2026-10-23/README.md)

<a id="TASK-29"></a>
## TASK-29 実機受入

参照：BF-08 / REQ-29 / FS-29 / TS-29 / TASK-29 / CODE-29 / TEST-29 / AT-29 / OPS-29 / USR-29

受入確認タスク：予約・取消・残高確認を各実機で実施。

完了条件：入力・確認・操作が可能、受入担当の確認記録あり。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

今回の実環境観測：DEV29-IOS-OBS-01〜04：iPhone 16 Pro Max・iOS26.6.2・Safariで管理者2、生徒3名・履歴3件・残数7/1/10・一覧右端列を画像確認。ログアウト後再読込でもログイン画面のみ・台帳非表示と本人が明示回答。iPhone管理者読取範囲は確認済み。Android・保護者本人・予約取消は未実施、AT-29全体未合格。 [確認記録](device-readonly-2026-10-24/README.md)

<a id="TASK-30"></a>
## TASK-30 リリース後スモークテスト

参照：BF-08 / REQ-30 / FS-30 / TS-30 / TASK-30 / CODE-30 / TEST-30 / AT-30 / OPS-30 / USR-30

受入確認タスク：将来本番開始が承認され、配備された後に、開発担当が本番URLで権限・予約・取消・連携・版を確認する。現在は本番開始を保留中。

完了条件：対象コミットと公開版一致、重大不具合なし、戻し手順あり。

状態：HOLD。実装参照が存在することと受入合格は別。

今回の実環境観測：RA-06：現行配布記録の公開7ファイルとSHA-256一致。古い固定版との比較失敗は棄却記録として保持。本番AT-30・実Google受入の合格ではない。 [確認記録](restored-admins-2026-10-23/README.md)

<a id="TASK-31"></a>
## TASK-31 管理者による利用登録・停止・削除

参照：BF-09 / REQ-31 / FS-31 / TS-31 / TASK-31 / CODE-31 / TEST-31 / SAT-31 / OPS-31 / USR-31

受入確認タスク：A06で登録・停止・再有効化・削除を行い次の通信の権限を確認。

完了条件：許可リストだけを変更。業務履歴・Google本人は削除せず、自分の停止削除・最後の管理者喪失を拒否。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

今回の実環境観測：RA-07/08：両管理者の公開管理画面で、有効・本人確認済みの管理者2名、一時検証家庭なしを確認。許可設定の書込は実施していない。 [確認記録](restored-admins-2026-10-23/README.md)

<a id="TASK-32"></a>
## TASK-32 初回Google本人紐付け

参照：BF-09 / REQ-32 / FS-32 / TS-32 / TASK-32 / CODE-32 / TEST-32 / SAT-32 / OPS-32 / USR-32

受入確認タスク：事前登録した本人で初回ログイン。未確認メール・停止済み・他人で試す。

完了条件：正しい本人だけ一度UIDへ移行し、役割を自己選択できない。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

今回の実環境観測：RA-04：公開保護者入口の入力欄0・管理者メニューなし・台帳なしを確認。家庭本人での実ログインは今回未実施。 [確認記録](restored-admins-2026-10-23/README.md)

<a id="TASK-33"></a>
## TASK-33 家庭URL・QRの配布と再発行

参照：BF-09 / REQ-33 / FS-33 / TS-33 / TASK-33 / CODE-33 / TEST-33 / SAT-33 / OPS-33 / USR-33

受入確認タスク：A05で表示・コピー。A06で再発行後、新旧URLで本人ログイン。

完了条件：URLにキー・メールを含めず、旧URLは次の通信から拒否。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

今回の実環境観測：RA-05：不正形式の家庭URLはURL確認画面、家庭データ非表示。発行・失効を含むSAT-33全体の合格ではない。 [確認記録](restored-admins-2026-10-23/README.md)

<a id="TASK-34"></a>
## TASK-34 Google認証・再読込・ログアウト

参照：BF-07 / REQ-34 / FS-34 / TS-34 / TASK-34 / CODE-34 / TEST-34 / SAT-34 / OPS-34 / USR-34

受入確認タスク：管理者2名・家庭2つを別セッションでログイン・再取得・終了。

完了条件：本人の役割と家庭を維持し、無効化・入口不一致・ログアウト後の業務アクセスを拒否。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

今回の実環境観測：RA-01/02-LOGOUT：復元後の両管理者についてログアウト直後・再読込後とも管理者ログイン画面だけとなり、台帳非表示を確認。 [確認記録](restored-admins-2026-10-23/README.md)

<a id="TASK-35"></a>
## TASK-35 台帳直接編集と反映

参照：BF-10 / REQ-35 / FS-35 / TS-35 / TASK-35 / CODE-35 / TEST-35 / SAT-35 / OPS-35 / USR-35

受入確認タスク：同時操作停止・バックアップ後、検証台帳の対象値を修正しサイト再取得。

完了条件：検証コピーと元台帳は非同期。直接修正で予定同期・消費計算・関連履歴更新を自動実行しない。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-36"></a>
## TASK-36 カレンダー確認・実送迎・実績確認

参照：BF-06 / REQ-36 / FS-36 / TS-36 / TASK-36 / CODE-36 / TEST-36 / SAT-36 / OPS-36 / USR-36

受入確認タスク：時刻・生徒・場所を確認し、お迎え／送り／往復を実施した記録を確認後に完了登録。

完了条件：実移動やカレンダー閲覧だけで自動消費しない。未実施・取消を完了にしない。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-37"></a>
## TASK-37 日時・場所変更と直前連絡

参照：BF-05 / REQ-37 / FS-37 / TS-37 / TASK-37 / CODE-37 / TEST-37 / SAT-37 / OPS-37 / USR-37

受入確認タスク：旧予約取消の成功を照合して新しい内容を登録し二重予約がないか確認。

完了条件：取消と新規は別処理。片方だけ成功した場合は結果照合し盲目的に再送しない。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-38"></a>
## TASK-38 工程横断のID・整合検査・共通デザイン

参照：BF-11 / REQ-38 / FS-38 / TS-38 / TASK-38 / CODE-38 / TEST-38 / SAT-38 / OPS-38 / USR-38

受入確認タスク：正本変更→生成→検査。重複ID・欠落・参照切れ・仕様値相違の異常系も確認。

完了条件：異常時に非ゼロ終了。履歴と現行・自動試験と実受入を分離し、現行PPTは共通テーマ。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

<a id="TASK-39"></a>
## TASK-39 随時実施できる顧客確認と検証専用の両画面アクセス

参照：BF-08 / REQ-39 / FS-39 / TS-39 / TASK-39 / CODE-39 / TEST-39 / SAT-39 / OPS-39 / USR-39

受入確認タスク：家庭用固定URLでCUST-01〜03→ログアウト→管理者用固定URLのA03でCUST-04→家庭用URLで残少案内→管理者用URLで10枚0円を追加→家庭用URLで12枚を確認。両画面でログアウト後非表示を確認。中断時は共有表に記録し未実施だけ再開。

完了条件：検証担当の読み書きは割当生徒だけ。設定と結合台帳IDが一致しない場合は拒否。生徒新規・利用者管理・他家庭一覧を拒否し、画面ごとの権限をサーバーで毎回再判定。固定日の予約を一覧で完了できる。顧客本人の未実施を合格にしない。

状態：PENDING_ACCEPTANCE。実装参照が存在することと受入合格は別。

